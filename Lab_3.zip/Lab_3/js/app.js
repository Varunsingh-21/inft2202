// Full Name: Varun Deep Singh
// Student Id:100865156
// Date Completed:Feb 22,2024

// user class with the attributes to instantiate a User object
class User {
    // default constructor
    constructor(firstName, lastName, username, email, password,confirmPassword) {
        this.fName = firstName;
        this.lName = lastName;
        this.username = username;
        this.emailadd = email;
        this.password = password;             
        this.confirmPassword = confirmPassword;            
    }
}


class User
{
    constructor(firstName , lastName, emailAddress , password , confirmPassword)
    {
        this.firstName = firstName;
        this.lastName = lastName;
        this.emailAddress = emailAddress;
        this.password = password;
        this.confirmPassword = confirmPassword;
    }
}


